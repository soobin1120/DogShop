package com.peisia.spring.mi.vo.dog;

import lombok.Data;

@Data
public class DogVO {
private int pdNum;
private String pdName;
private int pdPrice;
private String pdInfo;
private String pdImg;
private String cateCode;
}
