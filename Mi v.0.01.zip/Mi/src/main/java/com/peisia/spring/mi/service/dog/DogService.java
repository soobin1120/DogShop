package com.peisia.spring.mi.service.dog;

import com.peisia.spring.mi.vo.dog.DogVO;

public interface DogService {
	public void upload(DogVO dvo) throws Exception;
}
