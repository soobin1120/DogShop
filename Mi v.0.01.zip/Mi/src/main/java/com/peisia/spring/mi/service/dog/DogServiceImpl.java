package com.peisia.spring.mi.service.dog;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.dog.DogMapper;
import com.peisia.spring.mi.vo.dog.DogVO;

@Service
public class DogServiceImpl implements DogService{

	@Autowired
	DogMapper mapper;

	@Override
	public void upload(DogVO dvo) throws Exception {
		mapper.upload(dvo);
		
	}
	
	
}
