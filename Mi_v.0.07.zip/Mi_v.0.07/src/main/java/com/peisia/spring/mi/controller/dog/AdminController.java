package com.peisia.spring.mi.controller.dog;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.peisia.spring.mi.service.dog.DogService;
import com.peisia.spring.mi.vo.dog.DogVO;

import lombok.extern.log4j.Log4j;

@Controller
@RequestMapping("/dog/admin")
@Log4j
public class AdminController {

	@Autowired
	private DogService service;
	
	@RequestMapping(value="/main",method=RequestMethod.GET)
	public void adminMainGET() throws Exception{
		log.info("관리자 페이지로 이동");
	}
	
	@GetMapping("/del")
	public String del(@RequestParam("pdNum") int pdNum) {
		log.info("컨트롤러 삭제 글번호" + pdNum);
		service.del(pdNum);
		return "redirect:/dog/admin/getList";
	}
	
	@GetMapping("/getList")
	public void getList(@RequestParam(value="currentPage",defaultValue="1")int currentPage, Model model) {
		log.info("상품 목록 페이지 접속");
		model=service.getList(model,currentPage);
	}
	
	@RequestMapping(value="upload",method=RequestMethod.GET)
	public void uploadGET(Model model) throws Exception{
		log.info("상품 등록 페이지 접속");
		
		ObjectMapper objm = new ObjectMapper();

		List list = service.cateList();
	
		String cateList=objm.writeValueAsString(list);
		
		model.addAttribute("cateList",cateList);
		
		log.info("변경 전.........." + list);
		log.info("변경 후.........." + cateList);
	}
	
	@PostMapping("/uploadAjaxAction")
	public void uploadAjaxActionPOST(MultipartFile[] uploadFile) {
		String uploadFolder = "C:\\upload";
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
		
		Date date = new Date();
		
		String str = sdf.format(date);
		
		String datePath = str.replace("-", File.separator);
		
		/* 폴더 생성 */
		File uploadPath = new File(uploadFolder, datePath);
		
		if(uploadPath.exists() == false) {
			uploadPath.mkdirs();
		}
		
		for(MultipartFile multipartFile : uploadFile) {
			
			/* 파일 이름 */
			String uploadFileName = multipartFile.getOriginalFilename();
			
			/* uuid(범용 고유 식별자) 적용 파일 이름 */
			String uuid = UUID.randomUUID().toString();
			
			uploadFileName = uuid + "_" + uploadFileName;
			
			/* 파일 위치, 파일 이름을 합친 File 객체 */
			File saveFile = new File(uploadPath, uploadFileName);
			
			/* 파일 저장 */
			try {
				multipartFile.transferTo(saveFile);
			} catch (Exception e) {
				e.printStackTrace();
			} 
				
		}
	}
	
	@GetMapping({"/productDetail", "/modify"})
	public void productDetail(@RequestParam("pdNum")int pdNum,Model model) throws JsonProcessingException {
		log.info("컨트롤러 ===== 글번호 ====="+pdNum);
		ObjectMapper objm = new ObjectMapper();
		model.addAttribute("cateList",objm.writeValueAsString(service.cateList()));
		model.addAttribute("productDetail",service.productDetail(pdNum));
		
	}
	
	@PostMapping("/modify")
	public String modify(DogVO dvo) {
		service.modify(dvo);
		return "redirect:/dog/admin/getList";
	}

	
	@RequestMapping(value="upload.do",method=RequestMethod.POST)
	public String uploadPOST(DogVO dvo,RedirectAttributes rttr) throws Exception{
	 log.info("upload:"+dvo);
	 service.upload(dvo);
	 rttr.addFlashAttribute("upload_result",dvo.getPdName());
	return "redirect:/dog/admin/getList";
		
	}
	
}
