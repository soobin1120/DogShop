package com.peisia.spring.mi.mapper.dog;

import java.util.List;

import com.peisia.spring.mi.vo.dog.CateVO;
import com.peisia.spring.mi.vo.dog.DogVO;

public interface DogMapper {
	public int getCount();
	public List<DogVO>getList(int limitIndex);
	public void upload(DogVO dvo);
	public void modify(DogVO dvo);
	public List<CateVO> cateList();
	public DogVO productDetail(int pdNum);
	public void del(int pdNum);
}
	
	