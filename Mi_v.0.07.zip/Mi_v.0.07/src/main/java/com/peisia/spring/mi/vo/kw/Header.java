
package com.peisia.spring.mi.vo.kw;

public class Header {

    public String resultCode;
    public String resultMsg;

}
