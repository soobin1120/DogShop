package com.pesia.spring.mi.service.dog;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.peisia.spring.mi.mapper.dog.DogMapper;
import com.peisia.spring.mi.service.dog.DogService;
import com.peisia.spring.mi.vo.dog.DogVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class DogServiceTests {
@Autowired
private DogService service;
private DogMapper mapper;

/*
 * @Test public void uploadTest() throws Exception{ DogVO dvo=new DogVO();
 * 
 * dvo.setPdNum(3); dvo.setPdName("상품이름 3"); dvo.setPdPrice(6000);
 * dvo.setPdInfo("상품정보입니다3"); dvo.setPdImg("이미지입니다3");
 * 
 * service.upload(dvo); }
 */

@Test
public void productDetailTest() {
	int pdNum=111;
	DogVO result = mapper.productDetail(pdNum);
	System.out.println("상품 조회 데이터:"+result);
}
}
