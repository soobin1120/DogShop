package com.peisia.spring.mi.mapper.dog;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class DogMapperTests {
 
    @Autowired
    private AttachMapper attachMapper;
    
    @Autowired
    private DogMapper mapper;
  
    @Test
    public void deleteImageAllTest() {
    	
    	int pdNum=3;
    	mapper.deleteImageAll(pdNum);
    	
    }
}
