package com.pesia.spring.mi.service.dog;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.peisia.spring.mi.mapper.dog.DogMapper;
import com.peisia.spring.mi.service.dog.DogService;
import com.peisia.spring.mi.vo.dog.AttachImageVO;
import com.peisia.spring.mi.vo.dog.DogVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class DogServiceTests {
@Autowired
private DogService service;
private DogMapper mapper;

/*
 * @Test public void uploadTest() throws Exception{ DogVO dvo=new DogVO();
 * 
 * dvo.setPdNum(3); dvo.setPdName("상품이름 3"); dvo.setPdPrice(6000);
 * dvo.setPdInfo("상품정보입니다3"); dvo.setPdImg("이미지입니다3");
 * 
 * service.upload(dvo); }
 */

@Test
private void productUploadTests() throws Exception {
	DogVO dvo = new DogVO();
	
	dvo.setCateCode("101001");
	dvo.setPdName("강아지 목줄");
	dvo.setPdInfo("강아지 목줄입니다.");
	dvo.setPdPrice(20000);
	
	List<AttachImageVO> imageList = new ArrayList<AttachImageVO>();
	
	AttachImageVO image1 = new AttachImageVO();
	AttachImageVO image2 = new AttachImageVO();
	
	image1.setFileName("test Image 1");
	image1.setUploadPath("test Image 1");
	image1.setUuid("test1111");
	
	image2.setFileName("test Image 2");
	image2.setUploadPath("test Image 2");
	image2.setUuid("test2222");
	
	imageList.add(image1);
	imageList.add(image2);
	
	dvo.setImageList(imageList);
	
	service.upload(dvo);
	
	System.out.println("등록된 VO:" + dvo);
	
	
	
}
}
