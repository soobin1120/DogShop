package com.peisia.spring.mi.service.dog;

import java.util.List;

import com.peisia.spring.mi.vo.dog.AttachImageVO;

public interface AttachService {

	public List<AttachImageVO> getAttachList(int pdNum);
}
