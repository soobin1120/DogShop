
package com.peisia.spring.mi.vo.kw;

public class KWeatherVo {

    public Response response;

}
