package com.peisia.spring.mi.controller.dog;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.peisia.spring.mi.service.dog.DogService;

import lombok.extern.log4j.Log4j;

@Controller
@Log4j
public class ProdcutController {
	
	@Autowired
	private DogService service;

	@GetMapping("/dog/main")
	public void mainList(@RequestParam(value="currentPage",defaultValue="1")int currentPage, Model model) {
		
		
		model=service.mainList(model,currentPage);
		
	}
	
	
}
