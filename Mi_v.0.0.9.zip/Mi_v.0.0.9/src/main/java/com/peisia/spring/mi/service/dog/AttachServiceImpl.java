package com.peisia.spring.mi.service.dog;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.dog.AttachMapper;
import com.peisia.spring.mi.vo.dog.AttachImageVO;

import lombok.extern.log4j.Log4j;

@Service
@Log4j
public class AttachServiceImpl implements AttachService{

	@Autowired
	private AttachMapper mapper;
	
	@Override
	public List<AttachImageVO> getAttachList(int pdNum){
		
		log.info("getAttachList............");
		
		return mapper.getAttachList(pdNum);
	}
}
