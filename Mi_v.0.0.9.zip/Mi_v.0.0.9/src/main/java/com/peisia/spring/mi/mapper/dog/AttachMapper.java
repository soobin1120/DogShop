package com.peisia.spring.mi.mapper.dog;

import java.util.List;

import com.peisia.spring.mi.vo.dog.AttachImageVO;

public interface AttachMapper {

	
	public List<AttachImageVO> getAttachList(int pdNum);
}
