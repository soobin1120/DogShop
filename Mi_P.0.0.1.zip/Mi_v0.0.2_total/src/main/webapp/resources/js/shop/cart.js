$(document).ready(function() {
  var memberId = $("#memberId").val();
  var nonMemberId = $("#nonMemberId").val();
  var isLogin = !!memberId || !!nonMemberId;

  if (isLogin) {
    $.ajax({
      url: "/api/member/" + memberId + "/cart",
      type: "GET",
      success: function(memberCartData) {
        console.log(memberCartData);
        $.ajax({
          url: "/api/nonmember/" + nonMemberId + "/cart",
          type: "GET",
          success: function(nonMemberCartData) {
            console.log(nonMemberCartData);
            var cartData = (!!memberId) ? memberCartData : nonMemberCartData;
            var totalPrice = 0;
            var cartItemsHtml = '';
            cartData.forEach(function(cartItem) {
              var totalItemPrice = cartItem.gdsPrice * cartItem.cartStock;
              totalPrice += totalItemPrice;
              cartItemsHtml += `
                <tr>
                  <td>${cartItem.gdsNum}</td>
                  <td>${cartItem.gdsName}</td>
                  <td>${cartItem.gdsPrice}원</td>
                  <td>
                    <form action="updateCart" method="post">
                      <input type="hidden" name="gdsNum" value="${cartItem.gdsNum}">
                      <input type="hidden" name="gdsStock" value="${cartItem.gdsStock}">
                      <button type="submit" name="cartStock" value="1">+</button>
                      <span>${cartItem.cartStock}</span>
                      <button type="submit" name="cartStock" value="-1">-</button>
                    </form>
                  </td>
                  <td>${totalItemPrice}원</td>
                  <td>
                    <form action="deleteCartItem" method="post">
                      <input type="hidden" name="gdsNum" value="${cartItem.gdsNum}">
                      <button type="submit">삭제</button>
                    </form>
                  </td>
                </tr>
              `;
            });
            $("#cartTableBody").html(cartItemsHtml);
            $("#totalPrice").text(totalPrice + "원");
          }
        });
      }
    });
  }
});