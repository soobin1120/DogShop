 $(document).ready(function() {
    // 버튼 클릭 이벤트 핸들러 등록
    $("#btn").click(function() {
        // 확인/취소 알러트 창 띄우기
        if (confirm("정말로 실행하시겠습니까?")) {
            alert("실행되었습니다!");
        } else {
            alert("취소되었습니다.");
            return false;
        }
    });

    // img 클릭 이벤트 핸들러 등록
    $("#img").click(function(){
        $(this).css({
            width: "600px",
            height: "600px"
        });
    });
});


function showModal(img) {
    // 모달창 보이기
    $('#myModal').modal('show');
    
    // 모달창에 이미지 표시하기
    $('#myModal img').attr('src', img.src);
  }