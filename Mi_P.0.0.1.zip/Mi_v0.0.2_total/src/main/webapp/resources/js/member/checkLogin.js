function addToCart() {
    // 현재 로그인 상태인지 확인
    if (loggedIn) {
      // 로그인 되어있으면 카트에 담기
      // ...
    } else {
      // 로그인 되어있지 않으면 로그인 페이지로 이동
      alert("로그인이 필요합니다.");
      window.location.href = "/login.jsp";
    }
  }
  
  function addToWishlist() {
    // 현재 로그인 상태인지 확인
    if (loggedIn) {
      // 로그인 되어있으면 위시리스트에 담기
      // ...
    } else {
      // 로그인 되어있지 않으면 로그인 페이지로 이동
      alert("로그인이 필요합니다.");
      window.location.href = "/login.jsp";
    }
  }