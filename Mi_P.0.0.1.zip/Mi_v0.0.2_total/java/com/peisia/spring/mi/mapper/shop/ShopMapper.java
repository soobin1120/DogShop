package com.peisia.spring.mi.mapper.shop;

import java.util.List;

import com.peisia.spring.mi.vo.shop.ShopVO;

public interface ShopMapper {
    public List<ShopVO> selectGoodsList() throws Exception;
}