package com.peisia.spring.mi.mapper.member;

import com.peisia.spring.mi.vo.member.MemberVO;

public interface MemberMapper {
	
	public void join(MemberVO mvo);

	public MemberVO loginMember(MemberVO mvo);


}