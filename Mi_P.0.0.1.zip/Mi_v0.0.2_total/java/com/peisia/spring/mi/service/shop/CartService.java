package com.peisia.spring.mi.service.shop;

import java.util.List;

import com.peisia.spring.mi.vo.shop.CartVO;
import com.peisia.spring.mi.vo.shop.ShopVO;

public interface CartService {

	// 입력받은 회원 아이디에 해당하는 장바구니 정보를 데이터베이스에서 조회하여 리스트로 반환하는 쿼리.
	public List<CartVO> selectCartListByMemberId(String memberId);
    
	// 장바구니에 상품추가
    void addCartItem(CartVO cartItem);
    
    // 장바구니에 담겨있는 상품 총 합계
    int getTotalPrice();
	
    // 장바구니 정보 가져오기
	public CartVO getCart(CartVO cartVO) throws Exception;

	// 상품 정보 가져오기
	public ShopVO getShop(ShopVO shopVO) throws Exception;

}
