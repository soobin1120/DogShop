package com.peisia.spring.mi.service.member;

import com.peisia.spring.mi.vo.member.UserVO;

public interface UserService {

	public UserVO loginUser(UserVO uvo);

}
