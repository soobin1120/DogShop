package com.peisia.spring.mi.service.shop;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.shop.CartMapper;
import com.peisia.spring.mi.mapper.shop.ShopMapper;
import com.peisia.spring.mi.vo.shop.CartVO;
import com.peisia.spring.mi.vo.shop.ShopVO;

@Service("CartService")
public class CartServiceImpl implements CartService {
	@Autowired
	private CartMapper cartMapper;

	private List<CartVO> cartList;

	@Autowired
	private ShopMapper shopMapper;

	public CartServiceImpl() {
		this.cartList = new ArrayList<>();
	}

    @Override
    public void addCartItem(CartVO cartItem) {
        // 기존에 동일한 상품이 있는 경우 수량만 증가시킴
        for (CartVO item : this.cartList) {
            if (item.getGdsName().equals(cartItem.getGdsName())) {
                int stock = Integer.parseInt(item.getCartStock());
                stock += Integer.parseInt(cartItem.getCartStock()== null ? "1" : cartItem.getCartStock());
                item.setCartStock(Integer.toString(stock));
                return;
            }
        }
        // 동일한 상품이 없는 경우 리스트에 추가함
        CartVO newCartItem = new CartVO();
        newCartItem.addCartItem(cartItem);
        this.cartList.add(newCartItem);
    }

    @Override
    public int getTotalPrice() {
        int totalPrice = 0;
        for (CartVO item : this.cartList) {
            int price = Integer.parseInt(item.getGdsPrice().replace(",", ""));
            int stock = Integer.parseInt(item.getCartStock());
            totalPrice += price * stock;
        }
        return totalPrice;
    }
	
	// 입력받은 회원 아이디에 해당하는 장바구니 정보를 데이터베이스에서 조회하여 리스트로 반환하는 쿼리.
	@Override
	public List<CartVO> selectCartListByMemberId(String memberId) {
		return cartMapper.selectCartListByMemberId(memberId);
	}

	// 장바구니 정보 가져오기
	@Override
	public CartVO getCart(CartVO cartVO) throws Exception {
		return cartMapper.getCart(cartVO);
	}

	// 상품 정보 가져오기
	@Override
	public ShopVO getShop(ShopVO shopVO) throws Exception {
		return cartMapper.getShop(shopVO);
	}

}