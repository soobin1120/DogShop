package com.peisia.spring.mi.service.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.member.MemberMapper;
import com.peisia.spring.mi.vo.member.MemberVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class MemberServiceImpl implements MemberService {

	@Setter(onMethod_ = @Autowired)
	private MemberMapper mapper;

	@Override
	public void join(MemberVO mvo) {
		mapper.join(mvo);
	}

	@Override
	public MemberVO loginMember(MemberVO mvo) {
		return mapper.loginMember(mvo);
	}
	
}