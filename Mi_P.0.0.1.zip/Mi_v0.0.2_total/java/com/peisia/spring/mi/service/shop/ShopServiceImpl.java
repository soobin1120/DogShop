package com.peisia.spring.mi.service.shop;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.shop.ShopMapper;
import com.peisia.spring.mi.vo.shop.ShopVO;

@Service("shopService")
public class ShopServiceImpl implements ShopService {

    @Inject
    private ShopMapper shopMapper;

    @Override
    public List<ShopVO> selectGoodsList() throws Exception {
        return shopMapper.selectGoodsList();
    }

}