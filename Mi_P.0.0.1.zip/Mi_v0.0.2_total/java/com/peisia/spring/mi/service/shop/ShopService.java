 package com.peisia.spring.mi.service.shop;

import java.util.List;

import com.peisia.spring.mi.vo.shop.ShopVO;

public interface ShopService {
    public List<ShopVO> selectGoodsList() throws Exception;
}
