package com.peisia.spring.mi.service.dog;

import java.util.List;

import org.springframework.ui.Model;

import com.peisia.spring.mi.vo.dog.CateVO;
import com.peisia.spring.mi.vo.dog.DogVO;

public interface DogService {
	public void upload(DogVO dvo) throws Exception;
	public Model getList(Model m,int currentPage);
	public List<CateVO> cateList();
	public DogVO productDetail(int pdNum);
	public void modify(DogVO dvo);
	public void del(int pdNum);
}
