package com.peisia.spring.mi.service.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.member.UserMapper;
import com.peisia.spring.mi.vo.member.UserVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class UserServiceImpl implements UserService {

	@Setter(onMethod_ = @Autowired)
	private UserMapper mapper;

	@Override
	public UserVO loginUser(UserVO uvo) {
		return mapper.loginUser(uvo);
	}
	
}
