package com.peisia.spring.mi.service.member;

import com.peisia.spring.mi.vo.member.MemberVO;

public interface MemberService {
	
	public void join(MemberVO mvo);

	public MemberVO loginMember(MemberVO mvo);

}
