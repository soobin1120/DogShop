package com.peisia.spring.mi.controller.shop;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.peisia.spring.mi.service.shop.CartService;
import com.peisia.spring.mi.vo.member.MemberVO;
import com.peisia.spring.mi.vo.shop.CartVO;

@RestController
public class CartController {
	@Autowired
	private CartService cartService;

	// 로그인한 회원의 장바구니 정보조회
	@GetMapping("/shop/cart/{memberId}")
	public String selectCartListByMemberId(@PathVariable("memberId") String memberId, Model model) {
		List<CartVO> cartList = cartService.selectCartListByMemberId(memberId);
		model.addAttribute("cartList", cartList);
		return "shop/cart";
	}
	
	 // 장바구니에 상품 추가
    @RequestMapping(value = "/shop/cart/cartList", method = RequestMethod.POST)
    public String addCartItem(CartVO cartVO, HttpSession httpSession) throws Exception {
        MemberVO member = (MemberVO) httpSession.getAttribute("member");
        if (member == null) {
            return "redirect:/member/login";
        }
        cartVO.setMemberId(member.getMemberId());
        cartService.addCartItem(cartVO);
        return "redirect:/shop/cart/cartList";
    }
}
