package com.peisia.spring.mi.controller.member;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.peisia.spring.mi.service.member.UserService;
import com.peisia.spring.mi.vo.member.UserVO;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@SessionAttributes("userNum")
@Log4j
@RequestMapping("/user")
@AllArgsConstructor
@Controller
public class UserController {
	private UserService service;
	
	// 비회원 로그인 페이지
	@GetMapping("/loginUser")
	public String loginUser() {
		return "/user/loginUser";
	}

	// 비회원 로그인 처리
	@PostMapping("/loginUser")
	public String loginUser(UserVO uvo, Model u) {
		UserVO user = service.loginUser(uvo);

		if (user == null) {
			u.addAttribute("errorMsg", "주문정보를 찾을 수 없습니다.");
			return "/user/loginUser";
		}
    // 추후에 getUserName를 오더넘버로 바꿔야함
		u.addAttribute("userNum", user.getUserNum());
		return "redirect:/";
	}
	
	// 로그아웃 처리
	@GetMapping("/logout")
	public String logout(HttpSession s, SessionStatus status) {
		s.removeAttribute("userNum");
		status.setComplete();
		s.invalidate();
		return "redirect:/";
	}

}
