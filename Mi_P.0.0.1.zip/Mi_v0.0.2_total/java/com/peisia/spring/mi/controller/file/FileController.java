package com.peisia.spring.mi.controller.file;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import lombok.extern.log4j.Log4j;

@Log4j
@Controller
public class FileController {
	//// /resources/ 경로로 업로드 시	////
//	private static final String UPLOAD_DIR = "D:\\00_sungmo\\03_sts3_workspace\\Mi\\src\\main\\webapp\\resources\\upload\\";
//	private static final String UPLOAD_DIR = "src/main/webapp/resources/upload/";
//	private static final String UPLOAD_DIR = "src\\main\\webapp\\resources\\upload\\";
//	private static final String UPLOAD_DIR = "/resources/upload/";
//	private static final String UPLOAD_DIR = "\\resources\\upload\\"; << 다 안됨.
//	private static final String UPLOAD_DIR = "resources/upload/";
	private static String UPLOAD_DIR = "/resources/upload/";
	
	@Autowired
	private ServletContext servletContext;
	
	@GetMapping("/upload")
	public void upload(){}
	
	@PostMapping("/upload")
	public String upload(@RequestParam("file") MultipartFile file) {
		UPLOAD_DIR = servletContext.getRealPath("/resources/upload/");
	    // 파일 업로드 처리 로직
	    String fileName = file.getOriginalFilename();
	    Path filePath = Paths.get(UPLOAD_DIR + fileName);
        try {
            Files.write(filePath, file.getBytes());
        } catch (IOException e) {
            e.printStackTrace();
        }
	    return "upload_success";	// 업로드 후 돌아갈 화면. upload_success.jsp
	}
}