package com.peisia.spring.mi.controller.shop;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.peisia.spring.mi.service.shop.ShopService;
import com.peisia.spring.mi.vo.shop.ShopVO;

@RequestMapping("/shop/*")
@Controller
public class ShopController {
	@Autowired
	private ShopService shopService;
//  상품리스트
	@RequestMapping(value = "/goodsList", method = RequestMethod.GET)
	public ModelAndView goodsList() throws Exception {
		ModelAndView mav = new ModelAndView("shop/goodsList");
		List<ShopVO> goodsList = shopService.selectGoodsList();
		mav.addObject("goodsList", goodsList);
		return mav;
	}
//  상품상세페이지	
	@RequestMapping(value = "/show", method = RequestMethod.GET)
	public ModelAndView show() throws Exception {
		ModelAndView mav = new ModelAndView("shop/show");
		List<ShopVO> goodsList = shopService.selectGoodsList();
		mav.addObject("goodsList", goodsList);
		return mav;
	}
//  장바구니페이지	
	@RequestMapping("/cart")
	public void cart() {
	}
}
