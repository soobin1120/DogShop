package com.peisia.spring.mi.controller.member;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.peisia.spring.mi.service.member.MemberService;
import com.peisia.spring.mi.vo.member.MemberVO;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@SessionAttributes("id")
@Log4j
@RequestMapping("/member")
@AllArgsConstructor
@Controller
public class MemberController {
	private MemberService service;

	// 로그인 페이지
	@GetMapping("/loginMember")
	public String loginMember() {
		return "/member/loginMember";
	}

	// 회원 로그인 처리
	@PostMapping("/loginMember")
	public String loginMember(MemberVO mvo, Model m) {
		MemberVO member = service.loginMember(mvo);

		if (member == null) {
			m.addAttribute("errorMsg", "없는 아이디 또는 패스워드가 틀렸습니다.");
			return "/member/loginMember";
		}

		m.addAttribute("id", member.getMemberId());
		return "redirect:/";
	}
     
	// 회원가입 페이지
	@GetMapping("/join")
	public void join() {
	}
	
	// 회원가입 처리
	@PostMapping("/join")
	public String join(MemberVO mvo, Model model) {
	    try {
	        service.join(mvo);
	        return "redirect:/";
	    } catch (Exception e) {
	        model.addAttribute("errorMsg", "잘못된 정보거나 이미 있는 아이디입니다.");
	        return "/member/join";
	    }
	}
    
	// 로그아웃 처리
	@GetMapping("/logout")
	public String logout(HttpSession s, SessionStatus status) {
		s.removeAttribute("id");
		status.setComplete();
		s.invalidate();
		return "redirect:/";
	}
    
	// 나의 정보 페이지
	@GetMapping("/mypage")
	public void mypage() {
	}
}