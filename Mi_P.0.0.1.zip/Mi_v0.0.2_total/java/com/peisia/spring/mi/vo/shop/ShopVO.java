package com.peisia.spring.mi.vo.shop;

import java.sql.Timestamp;

public class ShopVO {
	private CartItemVO cartItem;
	private int gdsNum;       //  상품 번호
	private String gdsName;   //  상품 이름
	private int cateCode;     //  상품 분류 코드
	private int gdsPrice;     //  상품 가격
	private int gdsStock;     //  상품 수량
	private String gdsDes;    //  상품 설명
	private String gdsImg;    //  상품 이미지
	private Timestamp gdsDate;//  상품 등록날짜

	// Constructor
	public ShopVO() {
	}

	// 재고안 상품 수량 증가
	public void addGdsStock(int amount) {
		this.gdsStock += amount;
	}

	// 재고안 상품 수량 감소
	public void reduceGdsStock(int amount) {
		if (this.gdsStock - amount < 0) {
			this.gdsStock = 0;
		} else {
			this.gdsStock -= amount;
		}
		cartItem.addCartStock(amount); // 장바구니 수량 갱신
	}	
		
	public ShopVO(int gdsNum, String gdsName, int cateCode, int gdsPrice, int gdsStock, String gdsDes, String gdsImg,
			Timestamp gdsDate) {
		this.gdsNum = gdsNum;
		this.gdsName = gdsName;
		this.cateCode = cateCode;
		this.gdsPrice = gdsPrice;
		this.gdsStock = gdsStock;
		this.gdsDes = gdsDes;
		this.gdsImg = gdsImg;
		this.gdsDate = gdsDate;
	}

	// Getter and Setter methods
	// 상품 번호
	public int getGdsNum() {
		return gdsNum;
	}

	public void setGdsNum(int gdsNum) {
		this.gdsNum = gdsNum;
	}
    // 상품 이름
	public String getGdsName() {
		return gdsName;
	}

	public void setGdsName(String gdsName) {
		this.gdsName = gdsName;
	}
    // 상품 카테고리 번호
	public int getCateCode() {
		return cateCode;
	}
    
	public void setCateCode(int cateCode) {
		this.cateCode = cateCode;
	}
    // 상품 가격
	public int getGdsPrice() {
		return gdsPrice;
	}

	public void setGdsPrice(int gdsPrice) {
		this.gdsPrice = gdsPrice;
	}
    // 상품 수량
	public int getGdsStock() {
		return gdsStock;
	}

	public void setGdsStock(int gdsStock) {
		this.gdsStock = gdsStock;
	}
    // 상품 설명
	public String getGdsDes() {
		return gdsDes;
	}
    
	public void setGdsDes(String gdsDes) {
		this.gdsDes = gdsDes;
	}
    // 상품 이미지
	public String getGdsImg() {
		return gdsImg;
	}
    
	public void setGdsImg(String gdsImg) {
		this.gdsImg = gdsImg;
	}
    // 상품 등록날짜
	public Timestamp getGdsDate() {
		return gdsDate;
	}

	public void setGdsDate(Timestamp gdsDate) {
		this.gdsDate = gdsDate;
	}
}
