package com.peisia.spring.mi.vo.shop;

import lombok.Data;

@Data
public class CartVO {
	
	// 회원 장바구니
	private Integer cartNum;   // 장바구니 번호
	private String memberId;   // 회원 아이디
	private String gdsImg;     // 상품 이미지
	private String gdsName;    // 상품 이름
	private String gdsPrice;   // 상품 가격
	private String cartStock;  // 상품 수량
	
	// 장바구니에 담기
	public void addCartItem(CartVO cartItem) {
	    if (cartItem.getCartStock() == null) {
	        cartItem.setCartStock("1");
	    }
	    this.gdsImg = cartItem.getGdsImg();
	    this.gdsName = cartItem.getGdsName();
	    this.gdsPrice = cartItem.getGdsPrice();
	    this.cartStock = cartItem.getCartStock();
	}
	
	// 장바구니 안 총 합계 금액
	public int getTotalPrice() {
	    int price = Integer.parseInt(this.gdsPrice.replaceAll(",", ""));
	    int stock = Integer.parseInt(this.cartStock);
	    return price * stock;
	}
}
