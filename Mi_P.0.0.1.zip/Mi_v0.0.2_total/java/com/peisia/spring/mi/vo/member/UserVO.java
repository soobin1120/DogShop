package com.peisia.spring.mi.vo.member;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class UserVO {
//  비회원정보	
	private Integer userNum;
	private String userName;
	private String userEmail;
	private Integer userPhoneNum;
	private Timestamp userDate;
}
