package com.peisia.spring.mi.vo.member;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class MemberVO {
//  회원정보		
	private Integer memberNum;
	private String memberId;
	private String memberPw;
	private String memberName;
	private Integer memberBD;
	private String memberEmail;
	private Integer memberPhoneNum;
	private String memberImg;
	private Timestamp memberDate;
}
