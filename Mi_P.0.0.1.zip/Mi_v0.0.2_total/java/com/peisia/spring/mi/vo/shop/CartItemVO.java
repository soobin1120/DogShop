package com.peisia.spring.mi.vo.shop;

//장바구니 안에 추가된 상품 목록들을 만들기 위한 VO
public class CartItemVO {
	private CartVO cart; // 장바구니
	private ShopVO shop; // 상품
	private int cartStock; // 상품의 수량

	// Constructor
	public CartItemVO(CartVO cart, ShopVO shop, int cartStock) {
		this.cart = cart;
		this.shop = shop;
		this.cartStock = cartStock;
	}

	// 카트안 상품 수량 증가
	public void addCartStock(int amount) {
		this.cartStock += amount;
		shop.reduceGdsStock(amount); // ShopVO의 재고 수량 갱신
	}

	// 카트안 상품 수량 감소
	public void reduceCartStock(int amount) {
		if (this.cartStock - amount < 0) {
			this.cartStock = 0;
		} else {
			this.cartStock -= amount;
		}
		shop.addGdsStock(amount); // ShopVO의 재고 수량 갱신
	}

	// Getter and Setter methods
	public CartVO getCart() {
		return cart;
	}

	public void setCart(CartVO cart) {
		this.cart = cart;
	}

	public ShopVO getShop() {
		return shop;
	}

	public void setShop(ShopVO shop) {
		this.shop = shop;
	}

	public int getCartStock() {
		return cartStock;
	}

	public void setCartStock(int cartStock) {
		this.cartStock = cartStock;
	}

}