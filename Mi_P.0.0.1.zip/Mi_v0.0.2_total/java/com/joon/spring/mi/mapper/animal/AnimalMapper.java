package com.joon.spring.mi.mapper.animal;

import java.util.List;

import com.joon.spring.mi.vo.animal.AnimalVO;

public interface AnimalMapper {
	public int getCount();
	public List<AnimalVO> getList(int limitIndex);
	public AnimalVO read(int no);
	public void del(int no);
	public void write(AnimalVO gvo);
	public void modify(AnimalVO gvo);
}
