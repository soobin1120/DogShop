package com.joon.spring.mi.mapper.member;

import com.joon.spring.mi.vo.member.MemberVO;

public interface MemberMapper {

	public MemberVO login(MemberVO mvo);
}
