package com.joon.spring.mi.vo.animal;

import lombok.Data;

@Data
public class AnimalVO {
	private int no;
    private String impoundment_number;
    private String breed;
    private String kind;
    private String coat_color;
    private String gender;
    private String neutering;
    private String characteristic;
    private String additional_information;

    private String date_of_receipt;
    private String reason_for_rescue;
    private String location_found;
    private String start_stray_hold_period;
    private String end_stray_hold_period;

    private String jurisdictional_animal_shelter_name;
    private String shelter_location;
    private String phone_number;
    private String jurisdiction;
    private String contact_person;
    private String contact_person_number;
    private String notes;

    private String status;
    private String registration_number;
}