package com.joon.spring.mi.service.animal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.Model;

import com.joon.spring.mi.mapper.animal.AnimalMapper;
import com.joon.spring.mi.vo.animal.AnimalVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@Log4j
@Service
public class AnimalServiceImpl implements AnimalService{
	@Setter(onMethod_ = @Autowired)
	private AnimalMapper mapper;
	
	@Override
	public Model getList(Model m,int currentPage) {
		
		int listCountPerPage = 5;
		int pagesPerBlock = 3;
		int currentBlock = 1;
		int blockStartPage = 1;
		int blockEndPage = 1;
		int blockCount = 1;
		int	prevPage = 1;
		int	nextPage = 1;
		
		int limitIndex = (currentPage-1) * listCountPerPage;
		m.addAttribute("list",mapper.getList(limitIndex));
		
		int count = mapper.getCount();
		m.addAttribute("count",mapper.getCount());
		
		
		int totalPageCount = 0;
		totalPageCount = (int) Math.ceil((double)count / listCountPerPage);
		log.info("총 게시글 글 수는 "+count);
		log.info("총 페이지수 "+totalPageCount);
		m.addAttribute("totalPageCount", totalPageCount);
		m.addAttribute("pagesPerBlock", pagesPerBlock);
		
		blockCount = (int)Math.ceil((double)totalPageCount/pagesPerBlock);
		m.addAttribute("blockCount", blockCount);
		
		currentBlock=(int)Math.ceil((double)currentPage/pagesPerBlock);
		m.addAttribute("currentBlock", currentBlock);
		
		
		blockStartPage = (currentBlock-1) * pagesPerBlock + 1;
		blockEndPage = currentBlock * pagesPerBlock;
		if(blockEndPage > totalPageCount) {
			blockEndPage = totalPageCount;
		}
		m.addAttribute("blockStartPage", blockStartPage);
		m.addAttribute("blockEndPage", blockEndPage);
		
		if(currentBlock > 1) {
			m.addAttribute("hasBlockPrev", true);
			prevPage = (currentBlock - 1) * pagesPerBlock;
			m.addAttribute("prevPage", prevPage);
		}
		if(currentBlock < blockCount) {
			m.addAttribute("hasBlockNext", true);
			nextPage = currentBlock * pagesPerBlock + 1;
			m.addAttribute("nextPage", nextPage);
		}
		return m;
	}

	@Override
	public AnimalVO read(int no) {
		return mapper.read(no);
	}

	@Override
	public void del(int no) {
		mapper.del(no);
	}

	@Override
	public void write(AnimalVO gvo) {
		mapper.write(gvo);
	}

	@Override
	public void modify(AnimalVO gvo) {
		mapper.modify(gvo);
	}
	
}