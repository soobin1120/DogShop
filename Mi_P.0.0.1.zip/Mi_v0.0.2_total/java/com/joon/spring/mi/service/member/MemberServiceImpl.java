package com.joon.spring.mi.service.member;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.joon.spring.mi.mapper.member.MemberMapper;
import com.joon.spring.mi.vo.member.MemberVO;

import lombok.Setter;

@Service
public class MemberServiceImpl implements MemberService {

	@Setter(onMethod_ = @Autowired)
	private MemberMapper mapper;

	@Override
	public MemberVO login(MemberVO mvo) {
		return mapper.login(mvo);
	}
}