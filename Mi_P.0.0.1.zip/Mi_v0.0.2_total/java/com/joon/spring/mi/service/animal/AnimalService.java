package com.joon.spring.mi.service.animal;

import org.springframework.ui.Model;

import com.joon.spring.mi.vo.animal.AnimalVO;

public interface AnimalService {
	public Model getList(Model m, int currentPage);
	public AnimalVO read(int no);
	public void del(int no);
	public void write (AnimalVO gvo);
	public void modify (AnimalVO gvo);
}
