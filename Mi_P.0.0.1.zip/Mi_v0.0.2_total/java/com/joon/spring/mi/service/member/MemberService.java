package com.joon.spring.mi.service.member;

import com.joon.spring.mi.vo.member.MemberVO;

public interface MemberService {
	MemberVO login(MemberVO mvo);
}
