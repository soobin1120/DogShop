package com.joon.spring.mi.controller.member;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.joon.spring.mi.mapper.member.MemberMapper;
import com.joon.spring.mi.service.member.MemberService;
import com.joon.spring.mi.vo.member.MemberVO;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@SessionAttributes("id")
@Log4j
@AllArgsConstructor
@RequestMapping("/member")
@Controller
public class MemberController {
	private MemberService service;
	
	@PostMapping("/login")
	public String login(MemberVO mvo, Model m) {
		MemberVO member = service.login(mvo);
		m.addAttribute("id",member.getId());
		return "redirect:/";
	}
	
	@GetMapping("/login")
	public void login(){
	}
	
	@GetMapping("/join")
	public void join(MemberVO mvo) {
	}
}