package com.joon.spring.mi.controller.animal;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.joon.spring.mi.service.animal.AnimalService;
import com.joon.spring.mi.vo.animal.AnimalVO;

import lombok.AllArgsConstructor;
import lombok.extern.log4j.Log4j;

@Log4j
@RequestMapping("/animal")
@AllArgsConstructor
@Controller

public class AnimalController {
	private AnimalService service;

	@GetMapping("/getList")
	public void getList(@RequestParam("currentPage") int currentPage, Model model) {
		service.getList(model, currentPage);
	}

	@GetMapping("/index")
	public void index() {
	}

	@GetMapping("/home")
	public void home() {
	}

	@GetMapping({ "/read", "/modify" })
	public void read(@RequestParam("no") int no, Model model) {
		model.addAttribute("read", service.read(no));
	}

	@GetMapping("/del")
	public String del(@RequestParam("no") int no) {
		service.del(no);
		return "redirect:/animal/getList?currentPage=1";
	}

	@PostMapping("/write")
	public String write(AnimalVO gvo) {
		service.write(gvo);
		return "redirect:/animal/getList?currentPage=1";
	}

	@GetMapping("/write")
	public void write() {
	}

	@PostMapping("/modify")
	public String modify(AnimalVO gvo) {
		service.modify(gvo);
		return "redirect:/animal/getList?currentPage=1";
	}

}