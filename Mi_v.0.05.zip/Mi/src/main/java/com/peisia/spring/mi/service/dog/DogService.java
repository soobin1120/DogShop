package com.peisia.spring.mi.service.dog;

import java.util.List;

import com.peisia.spring.mi.vo.dog.CateVO;
import com.peisia.spring.mi.vo.dog.DogVO;

public interface DogService {
	public void upload(DogVO dvo) throws Exception;
	
	public List<CateVO> cateList();
}
