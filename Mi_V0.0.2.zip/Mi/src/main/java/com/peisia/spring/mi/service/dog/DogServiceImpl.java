package com.peisia.spring.mi.service.dog;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.peisia.spring.mi.mapper.dog.DogMapper;
import com.peisia.spring.mi.vo.dog.CateVO;
import com.peisia.spring.mi.vo.dog.DogVO;

import lombok.extern.log4j.Log4j;
@Log4j
@Service
public class DogServiceImpl implements DogService{

	@Autowired
	DogMapper mapper;

	@Override
	public void upload(DogVO dvo) throws Exception {
		mapper.upload(dvo);
		
	}
	
	@Override
	public List<CateVO> cateList(){
		log.info("(service)cateList.......");
		return mapper.cateList();
		
	}
	
}
