package com.peisia.spring.mi.mapper.dog;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import com.peisia.spring.mi.vo.dog.DogVO;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
public class DogMapperTests {
 
    @Autowired
    private DogMapper mapper;
    
    /* 작가 등록 테스트 */
    @Test
    public void upload() throws Exception{
        
        DogVO dvo = new DogVO();
        dvo.setPdNum(4);
        dvo.setPdName("상품이름 4");
        dvo.setPdPrice(5000);
        dvo.setPdInfo("상품정보입니다");
        dvo.setPdImg("이미지입니다");
        
        mapper.upload(dvo);
        
    }    
    
    @Test
    public void cateListTest() throws Exception{
    	System.out.println("cateList()......."+mapper.cateList());
    }
}
